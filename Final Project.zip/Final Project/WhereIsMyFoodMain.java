import java.util.Scanner;

public class WhereIsMyFoodMain {
    private String[] menu = {" 1. View Restaurant", " 2. Account Details", " 3. };
    
    
    public static void main(String[] args){

    }

    public void bootprogram(){

    }

    public void menuDisplay(){
        System.out.println("Welcome To Where Is My Food Delivery Program");


        
        
    }
}
