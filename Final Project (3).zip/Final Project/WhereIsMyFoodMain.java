import java.util.Scanner;

public class WhereIsMyFoodMain {
    private static Scanner input = new Scanner(System.in);
    private static FoodDelivery Admin = new FoodDelivery();
    private static String usernameinput;
    private static String emailinput;
    private static String idinput;
    private static String phonenumberInput;
    private static Menu menu1 = new Menu();
    private static String[] menu = {" 1. View Restaurants", " 2. Account Details", " 3. View My Order" };
    
    public static void main(String[] args){
        bootprogram();

    }

    public static void bootprogram(){
        int usrinput;
        System.out.println("Welcome To Where Is My Food Delivery Program");
        System.out.println("1. Login");
        System.out.println("2. Exit");
        usrinput = input.nextInt();

        switch(usrinput){
          

            case 1:
                login();
                StartmenuDisplay();
                break;

            case 2:
                break;
        }   

    }

    
    
    public static  boolean login(){
        
        System.out.println("Welcome To The Login Page");
        usernameinput = input.nextLine();
        System.out.print("1. Enter Username :");
        usernameinput = input.nextLine();
        System.out.print("2. Enter Ashesi ID:");
        idinput = input.nextLine();    
        System.out.print("3. Enter Ashesi Email Address :");
        emailinput = input.nextLine();
        System.out.print("3. Enter Phone NUmber:");
        phonenumberInput = input.nextLine();
        System.out.println("");
        return Admin.addAccount(new UserClass(usernameinput, emailinput,phonenumberInput,idinput ));
        
    }

    public static void StartmenuDisplay (){
        int menuselect;
        
        for(int s = 0; s < menu.length; s++){
            System.out.println(menu[s]);        
        }
        menuselect = input.nextInt();

        switch(menuselect){
            case 1:
                int restaurantselect;
                menu1.displayRestaurants();
                for (int i = 0; i < menu1.restaurantNames.length; i++) {
                    System.out.println(menu1.restaurantNames[i]);
                }

                System.out.print("Select Restaurant: ");
                restaurantselect = input.nextInt();
                System.out.println();
                selectrestaurant(restaurantselect);  
                break;

            case 2:
                System.out.println(FoodDelivery.users.toString());
                break;

            case 3:
                break;
                
            }  
        }

        public static void selectrestaurant(int restaurantselect){
            switch(restaurantselect){
                case 1:
                menu1.displayMunchiesenu();
                    break;
    
                case 2:
                menu1.displayAkonorMenu();
                    break;
    
                case 3:
                    menu1.displayBigBenMenu();
                    break;
                case 4:
                    StartmenuDisplay();
                }  
            }        
} 
