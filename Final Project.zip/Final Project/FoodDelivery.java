public class FoodDelivery{
    private int nOOfOrders;
    private static OrderClass[] orderlist;

    FoodDelivery(int n){
        nOOfOrders = n;
        orderlist = new OrderClass[nOOfOrders];
    }

    public void addOrder(OrderClass order){
        for (int i = 0; i < orderlist.length; i++){
            if (orderlist[i] == null) {
                orderlist[i] = order;
                break;
            }

        }
    }

    public void removeOrder(OrderClass order){
        for (int i = 0; i < orderlist.length; i++) {
            if (orderlist[i] == order) {
                orderlist[i] = null;
                break;
            }
        }
    }
}