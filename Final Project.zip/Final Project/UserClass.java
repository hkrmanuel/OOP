public class UserClass {

    private String userID;
    private String userName;
    private String email;
    private int phoneNumber;

    public UserClass(String userName, String email, int phoneNumber) {
        this.userName = userName;
        this.email = email;
        this.phoneNumber = phoneNumber;

        for (int s = 0; s< 5; s++){
            char num = (char) (Math.random() * 50);
            userID += num;
        }
    }

    public String getUserID(){
        return userID;
    }
    public String getname(){
        return userName;
    }

    public String getemail(){
        return email;
    }

    
}   

    
    
